var searchData=
[
  ['level',['level',['../structbadgerdb_1_1_non_leaf_node_int.html#a1409af967028a575417da623134f1f7f',1,'badgerdb::NonLeafNodeInt::level()'],['../structbadgerdb_1_1_non_leaf_node_double.html#ab83d10a511065a3d91411f4e5ccf0244',1,'badgerdb::NonLeafNodeDouble::level()'],['../structbadgerdb_1_1_non_leaf_node_string.html#ae90b5d494f51fc2fc7969fe0d7f39b54',1,'badgerdb::NonLeafNodeString::level()']]]
];
