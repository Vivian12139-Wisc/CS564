var searchData=
[
  ['clear',['clear',['../structbadgerdb_1_1_buf_stats.html#a04a848e5458491fd3ea56133464cadbd',1,'badgerdb::BufStats']]],
  ['clearbufstats',['clearBufStats',['../classbadgerdb_1_1_buf_mgr.html#a702a264ae946b334414e51700edd81a0',1,'badgerdb::BufMgr']]],
  ['close',['close',['../classbadgerdb_1_1_file.html#aa94ba5a754d0173b173e617127ec63c4',1,'badgerdb::File']]],
  ['create',['create',['../classbadgerdb_1_1_page_file.html#a474a82eb02ee89923f7b477749a18b82',1,'badgerdb::PageFile::create()'],['../classbadgerdb_1_1_blob_file.html#a6b8590b643fd49398e0a41c1e6d41757',1,'badgerdb::BlobFile::create()']]]
];
