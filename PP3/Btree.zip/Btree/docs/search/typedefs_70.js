var searchData=
[
  ['pageid',['PageId',['../namespacebadgerdb.html#a1f49e404293bf4240756b89b53b1587a',1,'badgerdb']]]
];
