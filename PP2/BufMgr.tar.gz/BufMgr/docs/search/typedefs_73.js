var searchData=
[
  ['slotid',['SlotId',['../namespacebadgerdb.html#afe9f2f985e7c67e04f76a16f7c4500c8',1,'badgerdb']]]
];
