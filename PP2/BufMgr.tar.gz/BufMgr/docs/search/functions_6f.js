var searchData=
[
  ['open',['open',['../classbadgerdb_1_1_file.html#a8462afdbd250c0a483ddfbde144c8732',1,'badgerdb::File']]],
  ['operator_21_3d',['operator!=',['../structbadgerdb_1_1_record_id.html#a0639e3a101d04340853a2b8eedccdf98',1,'badgerdb::RecordId']]],
  ['operator_2a',['operator*',['../classbadgerdb_1_1_file_iterator.html#a425810cc9834e0a3c97da76cd0a6b10a',1,'badgerdb::FileIterator::operator*()'],['../classbadgerdb_1_1_page_iterator.html#a5e9f06b5a70663086720fd919a5b6bdb',1,'badgerdb::PageIterator::operator*()']]],
  ['operator_2b_2b',['operator++',['../classbadgerdb_1_1_file_iterator.html#a6fa0f1cef8b46bb933ce6f000276ab52',1,'badgerdb::FileIterator::operator++()'],['../classbadgerdb_1_1_page_iterator.html#a2e63f3eea97170b2c566d1549a2215f0',1,'badgerdb::PageIterator::operator++()']]],
  ['operator_3d',['operator=',['../classbadgerdb_1_1_file.html#ac403c631aec085e9f12992f260a57155',1,'badgerdb::File']]],
  ['operator_3d_3d',['operator==',['../structbadgerdb_1_1_file_header.html#ae6439483acdb0eee52654c9c401793ca',1,'badgerdb::FileHeader::operator==()'],['../classbadgerdb_1_1_file_iterator.html#a373f648963527f2dd259980434686645',1,'badgerdb::FileIterator::operator==()'],['../structbadgerdb_1_1_page_header.html#ab5ecd22f86e37705cd7f29bc57255586',1,'badgerdb::PageHeader::operator==()'],['../classbadgerdb_1_1_page_iterator.html#a1111e07de5972ffd9244e312ac938dac',1,'badgerdb::PageIterator::operator==()'],['../structbadgerdb_1_1_record_id.html#a156dc24ebdd2ed2f8ce49b60326646c7',1,'badgerdb::RecordId::operator==()']]]
];
